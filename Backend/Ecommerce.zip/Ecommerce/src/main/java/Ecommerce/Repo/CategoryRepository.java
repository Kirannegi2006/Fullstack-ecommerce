package Ecommerce.Repo;

public interface CategoryRepository {

}
