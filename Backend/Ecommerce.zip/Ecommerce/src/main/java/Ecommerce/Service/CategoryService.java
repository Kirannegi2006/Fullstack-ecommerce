package Ecommerce.Service;

import java.util.List;

import Ecommerce.Entity.Category;

public interface CategoryService {

    List<Category> getAllCategories();

    Category getCategoryById(Long id);

    Category createCategory(Category category);

    Category updateCategory(Long id, java.util.Locale.Category category);

    boolean deleteCategory(Long id);
}

